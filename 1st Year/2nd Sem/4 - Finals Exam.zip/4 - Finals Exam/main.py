import customtkinter as ctk
from tkinter import ttk, messagebox
from database import DatabaseManager

# Global iOS-inspired theme settings
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

class MainApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Bean & Brew Manager")
        self.geometry("1100x700")
        self.db = DatabaseManager()

        # Layout Configuration
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # 1. SIDEBAR (iOS Navigation Style)
        self.sidebar = ctk.CTkFrame(self, width=200, corner_radius=0, fg_color="#F2F2F7")
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        
        self.logo_label = ctk.CTkLabel(self.sidebar, text="☕ Bean & Brew", font=ctk.CTkFont(size=20, weight="bold"))
        self.logo_label.pack(pady=30, padx=20)

        self.btn_dash = ctk.CTkButton(self.sidebar, text="Dashboard", command=self.show_dashboard, 
                                     corner_radius=12, fg_color="transparent", text_color="black", hover_color="#E5E5EA")
        self.btn_dash.pack(pady=10, padx=20, fill="x")

        self.btn_items = ctk.CTkButton(self.sidebar, text="Manage Items", command=self.show_items,
                                      corner_radius=12, fg_color="transparent", text_color="black", hover_color="#E5E5EA")
        self.btn_items.pack(pady=10, padx=20, fill="x")

        self.btn_cats = ctk.CTkButton(self.sidebar, text="Categories", command=self.show_categories,
                                     corner_radius=12, fg_color="transparent", text_color="black", hover_color="#E5E5EA")
        self.btn_cats.pack(pady=10, padx=20, fill="x")

        # 2. MAIN CONTENT AREA
        self.container = ctk.CTkFrame(self, corner_radius=20, fg_color="white")
        self.container.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.container.grid_columnconfigure(0, weight=1)
        self.container.grid_rowconfigure(0, weight=1)

        # Initialize Frames
        self.show_dashboard()

    def clear_container(self):
        for widget in self.container.winfo_children():
            widget.destroy()

    # --- VIEW 1: DASHBOARD (READ) ---
    def show_dashboard(self):
        self.clear_container()
        lbl = ctk.CTkLabel(self.container, text="Dashboard", font=ctk.CTkFont(size=24, weight="bold"))
        lbl.pack(pady=20)

        # iOS Style Table
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", background="white", foreground="black", rowheight=35, fieldbackground="white", borderwidth=0)
        style.map('Treeview', background=[('selected', '#007AFF')]) # iOS Blue

        tree_frame = ctk.CTkFrame(self.container, fg_color="transparent")
        tree_frame.pack(fill="both", expand=True, padx=30, pady=10)

        self.tree = ttk.Treeview(tree_frame, columns=("ID", "Name", "Price", "Stock", "Category"), show='headings')
        for col in ("ID", "Name", "Price", "Stock", "Category"):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor="center")
        self.tree.pack(fill="both", expand=True)

        self.load_data()

    def load_data(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        for row in self.db.fetch_menu_items(): self.tree.insert('', 'end', values=row)

    # --- VIEW 2: MANAGE ITEMS (CREATE / UPDATE / DELETE) ---
    def show_items(self, edit_data=None):
        self.clear_container()
        title = "Edit Item" if edit_data else "Add New Item"
        ctk.CTkLabel(self.container, text=title, font=ctk.CTkFont(size=24, weight="bold")).pack(pady=20)

        form_card = ctk.CTkFrame(self.container, fg_color="#F9F9F9", corner_radius=20, border_width=1, border_color="#D1D1D6")
        form_card.pack(pady=10, padx=100, fill="x")

        self.ent_name = self.create_input(form_card, "Item Name", edit_data[1] if edit_data else "")
        self.ent_price = self.create_input(form_card, "Price", edit_data[2] if edit_data else "")
        self.ent_stock = self.create_input(form_card, "Stock Quantity", edit_data[3] if edit_data else "")

        # Category Dropdown
        ctk.CTkLabel(form_card, text="Select Category", text_color="gray").pack(pady=(10,0))
        cats = self.db.fetch_categories()
        self.cat_map = {c[1]: c[0] for c in cats}
        self.dropdown = ctk.CTkOptionMenu(form_card, values=list(self.cat_map.keys()), corner_radius=10, fg_color="#007AFF")
        self.dropdown.pack(pady=20)

        btn_save = ctk.CTkButton(self.container, text="Save to Database", corner_radius=15, 
                                 height=45, fg_color="#34C759", hover_color="#28A745",
                                 command=lambda: self.save_item(edit_data[0] if edit_data else None))
        btn_save.pack(pady=10)

    def create_input(self, parent, label, value):
        ctk.CTkLabel(parent, text=label, text_color="gray").pack(pady=(15,0))
        entry = ctk.CTkEntry(parent, corner_radius=10, border_color="#C7C7CC", fg_color="white", text_color="black")
        entry.insert(0, value)
        entry.pack(pady=5, padx=40, fill="x")
        return entry

    def save_item(self, item_id):
        try:
            name, p, s = self.ent_name.get(), float(self.ent_price.get()), int(self.ent_stock.get())
            c_id = self.cat_map[self.dropdown.get()]
            if item_id: self.db.update_item(item_id, name, p, s)
            else: self.db.add_item(name, p, s, c_id)
            messagebox.showinfo("Success", "Database Updated!")
            self.show_dashboard()
        except: messagebox.showerror("Error", "Invalid Data Types")

    # --- VIEW 3: CATEGORIES ---
    def show_categories(self):
        self.clear_container()
        ctk.CTkLabel(self.container, text="Manage Categories", font=ctk.CTkFont(size=24, weight="bold")).pack(pady=20)
        
        entry_frame = ctk.CTkFrame(self.container, fg_color="transparent")
        entry_frame.pack(pady=10)
        
        self.cat_entry = ctk.CTkEntry(entry_frame, placeholder_text="Enter Category Name...", width=250, corner_radius=12)
        self.cat_entry.grid(row=0, column=0, padx=10)
        
        btn_add = ctk.CTkButton(entry_frame, text="Add", width=80, corner_radius=12, fg_color="#007AFF", 
                                command=self.add_category)
        btn_add.grid(row=0, column=1)

    def add_category(self):
        if name := self.cat_entry.get():
            self.db.add_category(name)
            self.cat_entry.delete(0, 'end')
            messagebox.showinfo("Success", "Category Created!")

if __name__ == "__main__":
    app = MainApp()
    app.mainloop()